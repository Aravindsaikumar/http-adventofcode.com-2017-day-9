﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace Problemsolution.BussinessLogic
{
    public class LogicBase
    {
        private string finaleStr = "";
        public LogicBase(string stream)
        {

            finaleStr = stream;
        }
        public int findgroup()
        {
            int finalscore = 0;
            int startBrace = 0;
            for (int i = 0; i < finaleStr.Length; i++)
            {
                if (finaleStr[i] == '<')
                {
                    for (int j = i; j < finaleStr.Length; j++)
                    {
                        if (finaleStr[j] == '>' && finaleStr[i - 1] != '!')
                        {
                            i = j;
                            break;
                        }
                        else
                        {
                            continue;
                        }
                    }
                }
                else if (finaleStr[i] == '{')
                {
                    startBrace++;
                }
                else if (finaleStr[i] == '}')
                {
                    if (startBrace > 0)
                    {
                        if (i > 3)
                        {
                            if (finaleStr[i - 1] == '>' && finaleStr[i - 2] == '!' && finaleStr[i - 3] != '!')
                            {
                                startBrace--;
                            }
                            else
                            {
                                finalscore += startBrace;
                                startBrace--;
                            }
                        }
                        else
                        {
                            finalscore += startBrace;
                            startBrace--;
                        }
                    }
                }

            }
            if (startBrace > 0)
            {
                finalscore -= startBrace;
            }
            return finalscore;
        }
    }
}