﻿using Problemsolution.BussinessLogic;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace Problemsolution.Controllers
{
    public class ReadFileController : ApiController
    {
        [HttpPost]
        public int Score()
        {
            int finalscore = 0;
            var httpRequest = HttpContext.Current.Request;
            if (httpRequest.Files.Count > 0)
            {
                var docfiles = new List<string>();
                foreach (string file in httpRequest.Files)
                {
                    var postedFile = httpRequest.Files[file];

                    StreamReader streamReader = new StreamReader(postedFile.InputStream);
                    string finaleStr = streamReader.ReadToEnd();
                    LogicBase lb = new LogicBase(finaleStr);
                    finalscore = lb.findgroup();
                }
            }
            return finalscore;
        }
    }
}
